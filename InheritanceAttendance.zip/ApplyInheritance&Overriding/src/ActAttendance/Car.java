package ActAttendance;

public class Car extends Vehicle{
	
	String tireType;
	
	Car(String name, String color, String speed, String price, String tireType){
		super(name,color,speed,price);
		this.tireType = tireType;
		
	}
	
	void infoVehicle() {
		super.infoVehicle();
		System.out.println("Tire type: " + tireType);
	}
	
	void drive() {
		System.out.println(name + " is driving around the city using " + tireType + 
				", the latest tire type of " + name);
	}
	
}
