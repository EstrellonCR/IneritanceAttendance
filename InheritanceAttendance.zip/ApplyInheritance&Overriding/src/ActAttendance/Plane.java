package ActAttendance;

public class Plane extends Vehicle{

	String wingSpan;
	
	Plane(String name, String color, String speed, String price, String wingSpan){
		super(name,color,speed,price);
		this.wingSpan = wingSpan;
		
	}
	
	void infoVehicle() {
		super.infoVehicle();
		System.out.println("Wing Span: " + wingSpan);
	}
	void fly() {
		System.out.println(name + " is flying in " + speed);
	}
}
