package ActAttendance;

public class Main {

	public static void main(String[] args) {
		
		Car c = new Car("Toyota-Vios", "Red", "60 km/h","PHP 1,005,000", "205/55 R16" );
		Plane p = new Plane("U-2 Spy Plane", "Black", "690 km/h","$10 million", "31 metres");
		Boat b = new Boat("Fandango Yacht", "White", "33 kph","Not For Sale", "Black");
		
		c.infoVehicle();
		c.drive();
		
		p.infoVehicle();
		p.fly();
		
		b.infoVehicle();
		b.Float();
		
	}

}
