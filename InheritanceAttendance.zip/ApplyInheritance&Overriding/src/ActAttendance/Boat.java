package ActAttendance;

public class Boat extends Vehicle{

	String mainSailColor;
	
	Boat(String name, String color, String speed, String price, String mainSailColor){
		super(name,color,speed,price);
		this.mainSailColor = mainSailColor;
		
	}
	
	void infoVehicle() {
		super.infoVehicle();
		System.out.println("MainSail color: " + mainSailColor);
	}
	
	void Float() {
		System.out.println(name + " is floating in the West Philippine Sea");
	}
}
