package ActAttendance;

public class Vehicle {
	
	String color, name, speed, price;
	
	Vehicle(String name, String color, String speed, String price){
		this.name = name;
		this.color = color;
		this.speed = speed;
		this.price = price;
	}
	void infoVehicle() {
		System.out.println("Name: " + name);
		System.out.println("Color: " + color);
		System.out.println("Speed: " + speed);
		System.out.println("Price: " + price);
	}
	void stop() {
		System.out.println("Vehicle has stopped");
	}
	
}
